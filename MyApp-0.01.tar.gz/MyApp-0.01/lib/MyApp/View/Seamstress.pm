package MyApp::View::Seamstress;

use strict;
#use base 'Catalyst::Base';
use base 'Catalyst::View::Seamstress';
use base qw(Class::Prototyped HTML::Seamstress);

use vars qw($comp_root);

BEGIN {
  $comp_root = "/ernest/dev/catalyst-simpleapp/MyApp/root/"; # IMPORTANT: last character must be "/"
}

use lib $comp_root;

__PACKAGE__->reflect->addSlot(comp_root => $comp_root) ;

1;


=head1 NAME

MyApp::View::Seamstress - Catalyst Seamstress View

=head1 SYNOPSIS

See L<MyApp>

=head1 DESCRIPTION

Catalyst Seamstress View.

=head1 METHODS

=head2 comp_root

This method returns the root of your html file tree which is normally something
like /full/path/to/MyApp/root/

=cut

sub comp_root { $comp_root }


=head1 AUTHOR

metaperl,,,

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
